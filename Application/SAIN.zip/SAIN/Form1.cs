﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ICSRadar
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                ListBox inProcessLB;
                for (int i = 1; i < 14; i++)
                {
                    tabControl1.TabPages[i].Text = "";
                    
                }
                for (int i = 1; i < 14; i++)
                {
                    ListBox lb = (ListBox)this.Controls.Find("listBox" + i.ToString(), true)[0];
                    lb.Items.Clear();
                }

               
                    //listBox1.Items.Clear();

                string AST;
                //var fileStream = new FileStream(@"ft.xml", FileMode.Open, FileAccess.Read);
                var fileStream = new FileStream(textBox1.Text, FileMode.Open, FileAccess.Read);
                using (var streamReader = new StreamReader(fileStream, Encoding.UTF8))
                {
                    AST = streamReader.ReadToEnd();
                }

                int tabCount = 0;
                while(AST.IndexOf("<function-block-declaration>") > -1)
                { 
                int sIndex = -1;
                int eIndex = -1;
                string temp = "";
                string fbName = "";
                    
                    AST = AST.Replace("<expression><integer-literal>", "<value><integer-literal>");
                    AST = AST.Replace("<expression><boolean-literal>", "<value><boolean-literal>");


                    sIndex = AST.IndexOf("<function-block-declaration>");
                temp = AST.Substring(sIndex);
                AST = AST.Substring(sIndex + 1);
                sIndex = temp.IndexOf("</function-block-declaration>");
                temp = temp.Substring(0,sIndex);
                sIndex = temp.IndexOf("<derived-function-block-name>");
                fbName = temp.Substring(sIndex + "<derived-function-block-name>".Length);
                sIndex = fbName.IndexOf("</derived-function-block-name>");
                fbName = fbName.Substring(0,sIndex);

                    
                if (fbName != "PRG_SSC_Ablauf" && fbName != "PRG_VGR_Ablauf" && fbName != "PRG_HBW_Ablauf" && fbName != "PRG_MPO_Ablauf" && fbName != "PRG_SLD_Ablauf")
                    continue;

               

                    string  tempFB = temp;                
                sIndex = tempFB.IndexOf("<case-statement>");
                if (sIndex == -1)
                {
                  // MessageBox.Show("No case statemnet");
                    continue;
                }
                    if (tabCount > 12)
                        break;
                    tabCount++;
                    inProcessLB = (ListBox)this.Controls.Find("listBox" + tabCount.ToString(), true)[0];
                    tabControl1.TabPages[tabCount - 1].Text = fbName;

                    tempFB = tempFB.Substring(sIndex);
                    sIndex = tempFB.IndexOf("<variable-name>");
                    tempFB = tempFB.Substring(sIndex);
                    string caseVariableName = tempFB.Substring( "<variable-name>".Length);
                    sIndex = caseVariableName.IndexOf("</variable-name>");
                    caseVariableName = caseVariableName.Substring(0, sIndex);


                    while (tempFB.Contains("<case-element>"))
                    {
                        sIndex = tempFB.IndexOf("<case-element>");
                        tempFB = tempFB.Substring(sIndex + "<case-element>".Length);
                        string caseElement = tempFB;
                        sIndex = tempFB.IndexOf("</case-element>");
                        caseElement = tempFB.Substring(0, sIndex);

                        //State name
                        string caseElementName = caseElement.Substring(caseElement.IndexOf("<case-list-element><integer-literal>") + "<case-list-element><integer-literal>".Length);
                        caseElementName = caseElementName.Substring(0, caseElementName.IndexOf("<"));
                        if (caseElementName == "290")
                        {

                        }
                        string allIfStatement = caseElement;
                        if (!allIfStatement.Contains("<if-statement>"))
                        {
                            inProcessLB.Items.Add("Current State:" + caseElementName + ",Next State: No Check");
                            continue;
                        }
                        while (allIfStatement.Contains("<if-statement>"))
                        {
                            sIndex = allIfStatement.IndexOf("<if-statement>");
                            allIfStatement = allIfStatement.Substring(sIndex + "<if-statement>".Length);
                            string ifStatement = allIfStatement;
                            sIndex = ifStatement.IndexOf("</if-statement>");
                            ifStatement = ifStatement.Substring(0, sIndex);

                            if (!ifStatement.Contains("<assignment-statement><variable-name>" + caseVariableName  + "</variable-name><value><integer-literal>"))
                            {
                                continue;
                            }

                            while (ifStatement.Contains("<expression>"))
                            {
                                sIndex = ifStatement.IndexOf("<expression>");
                                ifStatement = ifStatement.Substring(sIndex + "<expression>".Length);
                                string expressionString = ifStatement;                  
                                sIndex = expressionString.IndexOf("</expression>");
                                expressionString = expressionString.Substring(0, sIndex);
                                expressionString = expressionString.Replace("<logical-not></logical-not><multi-element-variable><variable-name>", "<multi-element-variable><variable-name>NOT ");
                                expressionString = expressionString.Replace("<logical-and></logical-and>", " AND ");
                                expressionString = expressionString.Replace("<logical-or></logical-or>", " OR ");
                                expressionString = expressionString.Replace("</variable-name><field-selector><variable-name>", ".");
                                expressionString = expressionString.Replace("<multi-element-variable><variable-name>", "");
                                expressionString = expressionString.Replace("</variable-name></field-selector></multi-element-variable>", "");
                                expressionString = expressionString.Replace("</variable-name></field-selector><field-selector><variable-name>", "");
                                expressionString = expressionString.Replace("<logical-not></logical-not>", "NOT ");
                                expressionString = expressionString.Replace("<variable-name>", "");
                                expressionString = expressionString.Replace("</variable-name>", "");
                                expressionString = expressionString.Replace("<adding></adding>", " + ");
                                expressionString = expressionString.Replace("<less-or-equal></less-or-equal>", " <= ");
                                expressionString = expressionString.Replace("<expression>", "");

                                if (expressionString.Contains("<expression>"))
                                {

                                }
                                //while (ifStatement.Contains("</statement-list>"))
                                {
                                    sIndex = ifStatement.IndexOf("</statement-list>");
                                    string statementList = ifStatement.Substring(0, sIndex);
                                    sIndex = ifStatement.IndexOf("</statement-list>");
                                    ifStatement = ifStatement.Substring(sIndex + "</statement-list>".Length);
                                    sIndex = statementList.IndexOf("<assignment-statement><variable-name>" + caseVariableName + "</variable-name><value><integer-literal>");
                                    if (sIndex == -1)
                                    {
                                        if (ifStatement.IndexOf("<assignment-statement><variable-name>" + caseVariableName + "</variable-name><value><integer-literal>") == -1)
                                        {
                                            continue;
                                        }
                                        else
                                        {
                                            sIndex = ifStatement.IndexOf("<assignment-statement><variable-name>" + caseVariableName + "</variable-name><value><integer-literal>");
                                            statementList = ifStatement;
                                        }
                                    }
                                    string nextState = statementList.Substring(sIndex + (("<assignment-statement><variable-name>" + caseVariableName + "</variable-name><value><integer-literal>").Length));
                                    sIndex = nextState.IndexOf("<");
                                    nextState = nextState.Substring(0, sIndex);
                                    inProcessLB.Items.Add("Current State:" + caseElementName + ",      Next State:" + nextState + ",        Transition Condition:" + expressionString);
                                }
                            }

                        }
                    }
                }

            }
            catch (Exception ex)

            {
                MessageBox.Show(ex.ToString());
            }
        }

        string getStringVal(string input, string startStr, string endStr)
        {
            string output = "";


            return output;

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    textBox1.Text = openFileDialog1.FileName;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < 14; i++)
            {
                tabControl1.TabPages[i].Text = "";
            }
        }
    }
}
